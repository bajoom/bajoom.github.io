# 👋 Bonjour, moi c’est Rasamoelison Vonimanana Rojoniaina  

🌈 **Créatrice passionnée par le digital et l’innovation.**  
Je conçois des sites web colorés, modernes et simples à utiliser.  
J’aime apprendre, créer et partager mes idées à travers mes projets.  

---

### 🚀 Mes projets
- 🌐 [Mon site personnel](https://bajoom.github.io)
- 💡 D’autres projets à venir bientôt…

---

### 📬 Me contacter
📧 **Email :** [rasamoelisonvonimananarojo@gmail.com](mailto:rasamoelisonvonimananarojo@gmail.com)  
💬 **WhatsApp :** [+261 33 19 820 29](https://wa.me/261331982029)  

---

✨ *Ce portfolio est mon premier pas vers 
