const images = document.querySelectorAll('.gallery img');
const popup = document.querySelector('.popup');
const popupImg = document.querySelector('.popup-img');
const closeBtn = document.querySelector('.close');

images.forEach(img => {
  img.addEventListener('click', () => {
    popup.style.display = 'flex';
    popupImg.src = img.src;
  });
});

closeBtn.addEventListener('click', () => {
  popup.style.display = 'none';
});

popup.addEventListener('click', (e) => {
  if (e.target !== popupImg) {
    popup.style.display = 'none';
  }
});
